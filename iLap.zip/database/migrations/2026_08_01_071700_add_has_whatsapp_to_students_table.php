<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasColumn('students', 'has_whatsapp')) {
            Schema::table('students', function (Blueprint $table) {
                $table->boolean('has_whatsapp')->default(false)->after('phone');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('students', 'has_whatsapp')) {
            Schema::table('students', function (Blueprint $table) {
                $table->dropColumn('has_whatsapp');
            });
        }
    }
};
